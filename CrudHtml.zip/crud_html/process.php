<?php

include 'config.php';

if(isset($_POST['register'])){
    $uname = $_POST['full-name'];
    $uemail = $_POST['your-email'];
    $upassword = $_POST['password'];
    $conpassword = $_POST['confirmpassword'];

    if(empty($uname) || empty($uemail) || empty($upassword) || empty($conpassword)){
        echo 'Feild Required';
    }
    else{
        if($upassword!=$conpassword){
            echo 'Password must be Identical';
        }
        else{

            $pass = md5($upassword);
            $sql = "INSERT INTO user (uname,uemail,upassword) values ('$uname','$uemail','$upassword')";
            $result = mysqli_query($conn,$sql);

            if($result){
                header("Location: http://localhost/crud_html/login.php");
            }
            else{
                echo 'There is Something wrong! try again';
            }

        }
    }
}
?>