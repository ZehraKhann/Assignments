<?php
$stu_id = $_GET['sid'];
$stu_name = $_GET['sname'];
$stu_address = $_GET['saddress'];
$stu_class = $_GET['sclass'];
$stu_phone = $_GET['sphone'];


$conn = mysqli_connect("localhost","root","","crud") or die ("Connection failed");
    $sql = "UPDATE  student SET sname = '{$stu_name}', saddress ='{$stu_address}' ,sclass = '{$stu_class}' ,sphone ='{$stu_phone}' WHERE sid={$stu_id}";
    $result = mysqli_query($conn , $sql) or die ("Query Unsuccessful");

    header("Location: http://localhost/crud_html/index.php");
    mysqli_close($conn);
?>