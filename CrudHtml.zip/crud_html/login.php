<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>SignUp</title>
	<!-- Mobile Specific Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!-- Font-->
	<link rel="stylesheet" type="text/css" href="assets/css/nunito-font.css">
	<!-- Main Style Css -->
    <link rel="stylesheet" href="assets/css/style.css"/>
</head>
<body class="form-v6">
	<div class="page-content">
		<div class="form-v6-content">
			<div class="form-left">
				<img src="assets/images/form-v6.jpg" alt="form">
			</div>
			<form class="form-detail" action="process1.php" method="POST">
				<h2>LogIn Form</h2>
				<div class="form-row">
					<input type="text" name="full-name" id="full-name" class="input-text" placeholder="Your Name" required>
				</div>
				<div class="form-row">
					<input type="text" name="your-email" id="your-email" class="input-text" placeholder="Email Address" required pattern="[^@]+@[^@]+.[a-zA-Z]{2,6}">
				</div>
				<div class="form-row">
					<input type="password" name="password" id="password" class="input-text" placeholder="Password" required>
				</div>
				<div class="form-row-last">
					<input type="submit" name="login" class="register" value="LogIn">
				</div>

				<div class="form-row">
					<a href="signup.php">If you are not registered ! Click here to Sign Up</a>
				</div>
			</form>
		</div>
	</div>
</body>
</html>