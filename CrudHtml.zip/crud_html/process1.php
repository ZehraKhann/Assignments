<?php

include 'config.php';

session_start();

if(isset($_POST['login'])){

    $uemail = $_POST['your-email'];
    $upassword = $_POST['password'];

    if(empty($uemail) || empty($upassword)){

        echo "Fill out the information";
    }
    else{
        $sql ="SELECT * FROM user WHERE uemail='$uemail' AND upassword = '$upassword'";

        $result = mysqli_query($conn,$sql);

        if(mysqli_num_rows($result) > 0) {

            $row = mysqli_fetch_assoc($result);

            $_SESSION ["uname"] = $row["uname"];
            header("Location: index.php");



        }
    }
    

}
?>