<?php
$stu_name = $_GET['sname'];
$stu_class = $_GET['sclass'];
$stu_phone = $_GET['sphone'];
$stu_address = $_GET['saddress'];

$conn = mysqli_connect("localhost","root","","crud") or die ("Connection failed");
    $sql = "INSERT INTO student(sname,sclass,sphone,saddress) VALUES ('{$stu_name}','{$stu_class}','{$stu_phone}','{$stu_address}')";
    $result = mysqli_query($conn , $sql) or die ("Query Unsuccessful");

    header("Location: http://localhost/crud_html/index.php");
    mysqli_close($conn);
?>